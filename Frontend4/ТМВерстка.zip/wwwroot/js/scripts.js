$(document).on('ready', function() {
         
		
		$(".rollover").imageChanger({
  			transition: false
		});

		 
		 
		 
		 
		 $('.row-foto').magnificPopup({
  			delegate: 'a', // child items selector, by clicking on it popup will open
  			type: 'image',
			gallery:{
   				enabled:true
  			},
			mainClass: 'mfp-fade'


  			// other options
		});
		 
		 
	
		$('.row-logistics').magnificPopup({
  			delegate: 'a', // child items selector, by clicking on it popup will open
  			type: 'image',
			gallery:{
   				enabled:true
  			},
			mainClass: 'mfp-fade'


  			// other options
		});
		 
		 
		 
		 


		
		
		
		
		
		
		 $(".questions-example").click(function() {
			 
			 
			 var text =$(this).find('p');
			 var icon = $(this).find('i');
			 $(text).slideToggle("slow");
			 $(text).toggleClass('open');
		     $(icon).toggleClass('fa-plus-circle');
		     $(icon).toggleClass('fa-minus-circle');
			 
			 });
		 
		 
		 $("#go").click(function() {
			   var storage_type=$("#storage").val();
			   var cargo_size=$("#size").val();
			   var cargo_days=$("#days").val();
			   var storage_rate = {};
               storage_rate["storage_warm"] = 9;
			   storage_rate["storage_cold"] = 22;
			   storage_rate["freezing"] = 27;
			   var in_sum=88.5*cargo_size;
			   var out_sum=88.5*cargo_size;
			   var storage_sum=storage_rate[storage_type]*cargo_size*cargo_days;
			   $("#in").val(in_sum);
			   $("#out").val(out_sum);
			   $("#storage-sum").val(storage_sum);
			   
			 
			 
			 });
		 
		 
		 
		 
		  
           $(".dis-sl").slick({
             
               dots: true,
               infinite: true,
               slidesToShow: 1,
               slidesToScroll: 1,
               prevArrow: '<div class="slick-prev-new"></div>',
               nextArrow: '<div class="slick-next-new"></div>'
    });

    $(".auction-sl").slick({

        dots: true,
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        prevArrow: '<div class="slick-prev-new"></div>',
        nextArrow: '<div class="slick-next-new"></div>'
    });
    $(".certif-sl").slick({

        dots: true,
        infinite: true,
        slidesToShow: 1,
        slidesToScroll: 1,
        prevArrow: '<div class="slick-prev-new"></div>',
        nextArrow: '<div class="slick-next-new"></div>'
    }); 
         
           
         });






// Dinrosta Theme JavaScript

(function($) {
	"use strict"; // Start of use strict


	// jQuery for page scrolling feature - requires jQuery Easing plugin
	$('a.nav-link').bind('click', function(event) {
		var $anchor = $(this);
		$('html, body').stop().animate({
			scrollTop: ($($anchor.attr('href')).offset().top - 50)
		}, 1500, 'easeInOutBack');
		event.preventDefault();
	});

	// Highlight the top nav as scrolling occurs
	$('body').scrollspy({
		target: '#navbarNavDropdown',
		offset: 51
		
	});
	
	
	$(window).scroll(function() {
  /* affix after scrolling 100px */
  if ($(document).scrollTop() > 50) {
    $('.navbar').addClass('affix');
  } else {
    $('.navbar').removeClass('affix');
  }
});
	
	$(".action-audit").click(function(event) {
			
			$("#form-modal h5").val('Заявка на аудит');
			return false;
	});
	
	$(".action-call").click(function(event) {
			var title = $(this).html();
			$("#form-modal h5").html('Заказать звонок');
			return false;
	});
	
	$(".action-try").click(function(event) {
			var title = $(this).html();
			$("#form-modal h5").html('Попробовать');
			return false;
	});


	// Closes the Responsive Menu on Menu Item Click
	$('.navbar-collapse ul li a').click(function(){ 
			$('.navbar-toggle:visible').click();
	});

	// Initialize lazy image loading
	//$('img.lazy').lazyload();

	// Fix nested modals problem (if topmost modal is closed, then scrolling is applied to the body)
	

	//
    
   
    
    
        var dotwidth = 0;
        $('.dis-sl').children('div').each(function (index, element) {
            dotwidth += 21;
        }
        );
        var ras1 = (($('.dis-sl').width() - dotwidth) / 2) - 30;
        var dotwidth = 0;
        $('.auction-sl').children('div').each(function (index, element) {
            dotwidth += 21;
        }
        );
        var ras2 = (($('.auction-sl').width() - dotwidth) / 2) - 30;
        var dotwidth = 0;
        $('.certif-sl').children('div').each(function (index, element) {
            dotwidth += 21;
        }
        );
        var ras3 = (($('.certif-sl').width() - dotwidth) / 2) - 30;
    
     
    function func() {
        $('.dis-sl .slick-prev-new').css("left", ras1 + "px");
        $('.dis-sl .slick-next-new').css("right", ras1 + "px");
        $('.auction-sl .slick-prev-new').css("left", ras2 + "px");
        $('.auction-sl .slick-next-new').css("right", ras2 + "px");
        $('.certif-sl .slick-prev-new').css("left", ras3 + "px");
        $('.certif-sl .slick-next-new').css("right", ras3 + "px");
    }

    setTimeout(func, 200);

})(jQuery); // End of use strict
